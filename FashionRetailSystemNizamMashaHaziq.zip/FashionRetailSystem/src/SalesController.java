import java.sql.ResultSet;

public class SalesController {
    private SalesData db = new SalesData();

    public Object[] searchItem(String code) {
        ResultSet rs = db.getItemByCode(code);
        try {
            if (rs != null && rs.next()) {
                if (rs.getInt("quantity") <= 0) return null; // Out of stock!
                return new Object[]{ code, rs.getString("name"), rs.getDouble("price"), 1 }; // Default qty to 1
            }
        } catch (Exception e) {}
        return null;
    }

    public double getDiscount(String voucherCode) {
        return db.checkVoucher(voucherCode);
    }
    
    public boolean finalizeSale(String invoiceID, double grandTotal, double discount) {
        return db.processCheckout(invoiceID, grandTotal, discount);
    }
}