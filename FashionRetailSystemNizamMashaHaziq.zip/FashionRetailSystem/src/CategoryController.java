public class CategoryController {
    CategoryData db = new CategoryData();

    public String processNewCategory(String name) {
        // CONSTRAINT: Cannot be blank
        if (name == null || name.trim().isEmpty()) {
            return "ERROR_BLANK";
        }
        // CONSTRAINT: Must be unique
        if (db.checkExists(name)) {
            return "ERROR_UNIQUE";
        }
        
        if (db.addCategory(name)) {
            return "SUCCESS";
        }
        return "ERROR_DB";
    }

    public String processUpdateCategory(String oldName, String newName) {
        if (newName == null || newName.trim().isEmpty()) return "ERROR_BLANK";
        if (oldName.equals(newName)) return "NO_CHANGE"; // Didn't actually change anything
        if (db.checkExists(newName)) return "ERROR_UNIQUE";

        // Check Exception Flow E1 condition
        boolean inUse = db.checkInUse(oldName);
        
        if (db.updateCategory(oldName, newName)) {
            if (inUse) {
                return "SUCCESS_WITH_WARNING"; // Triggers E1 response
            }
            return "SUCCESS";
        }
        return "ERROR_DB";
    }
    public String processDeleteCategory(String name) {
        if (name == null || name.trim().isEmpty()) {
            return "ERROR_BLANK";
        }

        // CRITICAL SECURITY CHECK: Prevent deletion if products are using it!
        if (db.checkInUse(name)) {
            return "ERROR_IN_USE";
        }

        // If it is safe, delete it
        if (db.deleteCategory(name)) {
            return "SUCCESS";
        }
        return "ERROR_DB";
    }
}