import java.sql.*;

public class SalesData {
    private Connection connect() {
        String url = "jdbc:mysql://localhost:3306/inventory_db";
        String user = "root";
        String password = ""; 
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            System.out.println("Database Connection Error: " + e.getMessage());
        }
        return conn;
    }

    // Find an item by code
    public ResultSet getItemByCode(String code) {
        String sql = "SELECT name, price, quantity FROM products WHERE productCode = ?";
        try {
            Connection conn = this.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, code);
            return pstmt.executeQuery();
        } catch (SQLException e) {
            return null;
        }
    }

    // Check if voucher exists
    public double checkVoucher(String code) {
        String sql = "SELECT discountValue FROM vouchers WHERE voucherCode = ? AND status = 'Active'";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, code);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getDouble("discountValue");
        } catch (SQLException e) {}
        return 0.0; // Returns 0 if invalid
    }

    // Save the final receipt
    public boolean processCheckout(String invoiceID, double total, double discount) {
        String sql = "INSERT INTO invoices(invoiceID, grandTotal, discountApplied, saleDate) VALUES(?,?,?, CURDATE())";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, invoiceID);
            pstmt.setDouble(2, total);
            pstmt.setDouble(3, discount);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
    
    // Deduct stock from the warehouse
    public void deductStock(String productCode, int qtyBought) {
        String sql = "UPDATE products SET quantity = quantity - ? WHERE productCode = ?";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, qtyBought);
            pstmt.setString(2, productCode);
            pstmt.executeUpdate();
        } catch (SQLException e) {}
    }
}