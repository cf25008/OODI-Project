public class SupplierController {
    private SupplierData db = new SupplierData();

    public String processRegistration(String name, String ssm, String phone, String address) {
        // Exception Flow E1: Semak pendua (Duplicate)
        if (db.isSSMExists(ssm)) {
            return "ERROR_DUPLICATE";
        }
        
        // Simpan jika tiada ralat
        if (db.saveSupplier(name, ssm, phone, address)) {
            return "SUCCESS";
        }
        return "ERROR_DB";
    }
    public java.util.ArrayList<Supplier> getSupplierList() {
        return db.getAllSuppliers();
    }
    // Proses Update
    public String processUpdate(String ssm, String phone, String address) {
        if (ssm.isEmpty()) {
            return "ERROR_NO_SELECTION";
        }
        if (db.updateSupplier(ssm, phone, address)) {
            return "SUCCESS";
        }
        return "ERROR_DB";
    }

    // Proses Deactivate
    public String processDeactivate(String ssm) {
        if (ssm.isEmpty()) {
            return "ERROR_NO_SELECTION";
        }
        if (db.deactivateSupplier(ssm)) {
            return "SUCCESS";
        }
        return "ERROR_DB";
    }
}