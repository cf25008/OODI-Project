public class PurchaseOrder {
    private String poNumber;
    private String supplierSSM;
    private double totalAmount;
    private String status;

    public PurchaseOrder(String poNumber, String supplierSSM, double totalAmount, String status) {
        this.poNumber = poNumber;
        this.supplierSSM = supplierSSM;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    // Getters
    public String getPoNumber() { return poNumber; }
    public String getSupplierSSM() { return supplierSSM; }
    public double getTotalAmount() { return totalAmount; }
    public String getStatus() { return status; }
}