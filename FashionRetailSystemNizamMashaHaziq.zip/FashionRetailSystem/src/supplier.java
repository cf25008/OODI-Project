public class Supplier {
    private String name;
    private String ssm;
    private String phone;
    private String address;

    // Constructor
    public Supplier(String name, String ssm, String phone, String address) {
        this.name = name;
        this.ssm = ssm;
        this.phone = phone;
        this.address = address;
    }

    // Getters
    public String getName() { return name; }
    public String getSsm() { return ssm; }
    public String getPhone() { return phone; }
    public String getAddress() { return address; }
}