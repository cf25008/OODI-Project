
import java.sql.*;
import java.util.ArrayList;

public class HistoryData {
    
    // Method untuk tarik semua data atau cari berdasarkan ID Invois
public ArrayList<Object[]> getInvoiceRecords(String searchKeyword) {
    ArrayList<Object[]> list = new ArrayList<>();
    
    // Pastikan SQL ni ambil kolom yang BETUL-BETUL ada dalam database awak
    String sql = "SELECT invoiceID, grandTotal, discountApplied, saleDate FROM invoices";
    if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
        sql += " WHERE invoiceID LIKE ?";
    }
    
    try (Connection conn = DatabaseConnectionFactory.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
         
        if (searchKeyword != null && !searchKeyword.trim().isEmpty()) {
            pstmt.setString(1, "%" + searchKeyword + "%");
        }
        
        ResultSet rs = pstmt.executeQuery();
        while (rs.next()) {
            // Urutan ni kena ikut betul-betul
            Object[] row = {
                rs.getString("invoiceID"),
                rs.getDouble("grandTotal"),
                rs.getDouble("discountApplied"),
                rs.getString("saleDate")
            };
            list.add(row);
        }
    } catch (SQLException e) {
        System.out.println("Error: " + e.getMessage());
    }
    return list;
    }
}
