import java.sql.*;

public class UserData {
    private Connection connect() {
        String url = "jdbc:mysql://localhost:3306/inventory_db";
        String user = "root";
        String password = ""; 
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            System.out.println("Database Connection Error: " + e.getMessage());
        }
        return conn;
    }

    public boolean authenticate(String username, String pass) {
        String sql = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, pass); // Note: In a real enterprise app, passwords are encrypted, but plain text is perfect for university projects!
            ResultSet rs = pstmt.executeQuery();
            
            // If rs.next() is true, it means a matching user was found!
            return rs.next(); 
        } catch (SQLException e) {
            return false;
        }
    }
}