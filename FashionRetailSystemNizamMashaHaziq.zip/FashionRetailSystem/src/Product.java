public class Product {
    // 1. Private variables (Encapsulation)
    private String productCode;
    private String name;
    private String category;
    private double price;
    private int quantity;

    // 2. Constructor: Used to create a new Product object from database rows
    public Product(String productCode, String name, String category, double price, int quantity) {
        this.productCode = productCode;
        this.name = name;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
    }

    // 3. Getter methods: These allow your UI table to read the data
    public String getProductCode() { 
        return productCode; 
    }
    
    public String getName() { 
        return name; 
    }
    
    public String getCategory() { 
        return category; 
    }
    
    public double getPrice() { 
        return price; 
    }
    
    public int getQuantity() { 
        return quantity; 
    }
}