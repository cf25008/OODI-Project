import java.util.ArrayList;

public class ProductController {
    
    // Create one instance of the Data layer to use for all methods
    private ProductData db = new ProductData();

    // UPGRADE FIX: We changed this from ResultSet to ArrayList<Product> for your 5 marks!
    public ArrayList<Product> getStockData() {
        return db.getAllProducts();
    }

    public boolean processNewProduct(String code, String name, String category, double price, int qty) {
        // Validation: Price and Quantity cannot be negative (Exception Flow E1)
        if (price < 0 || qty < 0) {
            return false; 
        }
        
        // SYNTAX FIX: I removed the broken curly braces that were blocking this line!
        // Tell the Data layer to save it
        return db.saveProduct(code, name, category, price, qty);
    }

    public boolean processDeleteProduct(String code) {
        return db.deleteProduct(code);
    }  

    public String updateProductDetails(String code, String name, String category, double price, int qty) {
        // Exception Flow E1: Check for negative price
        if (price < 0) {
            return "Error: Price cannot be a negative value.";
        }
        if (qty < 0) {
            return "Error: Quantity cannot be negative.";
        }

        if (db.updateProduct(code, name, category, price, qty)) {
            return "Success";
        } else {
            return "Error: Database update failed.";
        }
    }

    public ArrayList<Product> getFilteredStock(String category) {
        if (category.equals("All Categories")) {
            return db.getAllProducts();
        }
        return db.getProductsByCategory(category);
    }
}