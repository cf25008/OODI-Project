import java.util.ArrayList;

public class POController {
    private POData db = new POData();
    private final String MANAGER_PIN = "123456";

    // 1. Method untuk proses PO (Dah update untuk terima unitPrice)
    public String processNewPO(String poNumber, String supplierSSM, double unitPrice, double totalAmount, String enteredPin) {
        
        // Audit: Pastikan total tidak negatif
        if (totalAmount <= 0) return "ERROR_AMOUNT";
        
        // Constraint: Approve High Value PO (> RM5,000)
        if (totalAmount > 5000.00) {
            if (enteredPin == null || !enteredPin.equals(MANAGER_PIN)) {
                return "ERROR_PIN";
            }
        }
        
        String status = "Pending";
        
        // 2. Hantar unitPrice ke database (Pastikan POData pun dah update)
        if (db.savePurchaseOrder(poNumber, supplierSSM, unitPrice, totalAmount, status)) {
            return "SUCCESS";
        }
        
        return "ERROR_DB";
    }

    // Method untuk UI dapatkan senarai pembekal
    public java.util.ArrayList<String> getActiveSuppliers() {
        return db.getSupplierNames();
    }
}