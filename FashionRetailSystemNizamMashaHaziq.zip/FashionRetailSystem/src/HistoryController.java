
import java.util.ArrayList;

public class HistoryController {
    
    private HistoryData db = new HistoryData();
    
    public ArrayList<Object[]> loadPastSalesMetrics() {
        return db.getInvoiceRecords(null); // Tarik semua rekod
    }
    
    public ArrayList<Object[]> lookupSearchQuery(String serialToken) {
        if (serialToken == null || serialToken.trim().isEmpty()) {
            return loadPastSalesMetrics(); // Jika kotak kosong, tunjuk semua
        }
        return db.getInvoiceRecords(serialToken); // Filter berdasarkan ID
    }
}   

