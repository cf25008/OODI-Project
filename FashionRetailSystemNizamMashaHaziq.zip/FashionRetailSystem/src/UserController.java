public class UserController {
    private UserData db = new UserData();

    public boolean loginUser(String username, String password) {
        // Prevent empty submissions
        if (username.trim().isEmpty() || password.trim().isEmpty()) {
            return false; 
        }
        return db.authenticate(username, password);
    }
}