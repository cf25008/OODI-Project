import java.sql.*;

public class POData {
    
    // Menyimpan rekod PO baharu ke dalam database
    public boolean savePurchaseOrder(String poNumber, String supplierSSM, double totalAmount, String status) {
        String sql = "INSERT INTO purchase_orders (poNumber, supplierSSM, totalAmount, status) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
             
            pstmt.setString(1, poNumber);
            pstmt.setString(2, supplierSSM);
            pstmt.setDouble(3, totalAmount);
            pstmt.setString(4, status);
            pstmt.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            System.out.println("Database Error: " + e.getMessage());
            return false;
        }
    }
    // Tambahkan method ini ke dalam POData.java
    public java.util.ArrayList<String> getSupplierNames() {
        java.util.ArrayList<String> suppliers = new java.util.ArrayList<>();
        String sql = "SELECT name FROM suppliers"; // Pastikan nama table awak 'suppliers'
        
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
             
            while (rs.next()) {
                suppliers.add(rs.getString("name"));
            }
            
        } catch (SQLException e) {
            System.out.println("Error getSupplierNames: " + e.getMessage());
        }
        return suppliers;
    }
    public boolean registerSupplier(String name, String ssm, String phone, String address) {
    // SQL ikut nama column dalam screenshot awak (name, ssm, phone, address, status)
    String sql = "INSERT INTO suppliers (name, ssm, phone, address, status) VALUES (?, ?, ?, ?, 'Active')";
    
    try (Connection conn = DatabaseConnectionFactory.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
         
        pstmt.setString(1, name);
        pstmt.setString(2, ssm);
        pstmt.setString(3, phone);
        pstmt.setString(4, address);
        
        pstmt.executeUpdate();
        return true;
    } catch (SQLException e) {
        System.out.println("Error register supplier: " + e.getMessage());
        return false;
    }
}
    public boolean savePurchaseOrder(String poNumber, String supplierSSM, double unitPrice, double totalAmount, String status) {
    // 1. Tambah 'unitPrice' dalam SQL
    String sql = "INSERT INTO purchase_orders (poNumber, supplierSSM, unitPrice, totalAmount, status) VALUES (?, ?, ?, ?, ?)";
    
    try (Connection conn = DatabaseConnectionFactory.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
         
        // 2. Set parameter (pastikan turutan betul)
        pstmt.setString(1, poNumber);
        pstmt.setString(2, supplierSSM);
        pstmt.setDouble(3, unitPrice);   // Ini harga manual dari txtPrice
        pstmt.setDouble(4, totalAmount); // Ini total
        pstmt.setString(5, status);
        
        pstmt.executeUpdate();
        return true;
        
    } catch (SQLException e) {
        System.out.println("Database Error: " + e.getMessage());
        return false;
    }
}
    public boolean deleteSupplier(String ssm) {
    String sql = "DELETE FROM suppliers WHERE ssm = ?";
    try (Connection conn = DatabaseConnectionFactory.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, ssm);
        pstmt.executeUpdate();
        return true;
    } catch (SQLException e) {
        System.out.println("Error Delete: " + e.getMessage());
        return false;
    }
}
    // Tambah dalam POData.java
public java.util.ArrayList<Supplier> getAllSuppliers() {
    java.util.ArrayList<Supplier> list = new java.util.ArrayList<>();
    String sql = "SELECT * FROM suppliers";
    try (Connection conn = DatabaseConnectionFactory.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql);
         ResultSet rs = pstmt.executeQuery()) {
        while (rs.next()) {
            list.add(new Supplier(rs.getString("name"), rs.getString("ssm"), rs.getString("phone"), rs.getString("address")));
        }
    } catch (SQLException e) { System.out.println("Error load: " + e.getMessage()); }
    return list;
}

public boolean updateSupplier(String name, String phone, String address, String ssm) {
    String sql = "UPDATE suppliers SET name=?, phone=?, address=? WHERE ssm=?";
    try (Connection conn = DatabaseConnectionFactory.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
        pstmt.setString(1, name);
        pstmt.setString(2, phone);
        pstmt.setString(3, address);
        pstmt.setString(4, ssm);
        pstmt.executeUpdate();
        return true;
    } catch (SQLException e) { return false; }
}
}
