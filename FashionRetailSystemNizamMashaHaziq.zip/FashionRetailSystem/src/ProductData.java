import java.sql.*;
import java.util.ArrayList;

// The "implements" keyword fulfills the OOP Interface requirement!
public class ProductData implements InventoryOperations {

    @Override
    public boolean saveProduct(String code, String name, String category, double price, int qty) {
        String sql = "INSERT INTO products(productCode, name, category, price, quantity) VALUES(?,?,?,?,?)";
        // USING THE FACTORY PATTERN HERE:
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, code);
            pstmt.setString(2, name);
            pstmt.setString(3, category);
            pstmt.setDouble(4, price);
            pstmt.setInt(5, qty);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    @Override
    public ArrayList<Product> getAllProducts() {
        // USING THE ARRAYLIST DATA STRUCTURE HERE:
        ArrayList<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM products";
        
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                // Packing the database row into a secure Product object
                Product p = new Product(
                    rs.getString("productCode"),
                    rs.getString("name"),
                    rs.getString("category"),
                    rs.getDouble("price"),
                    rs.getInt("quantity")
                );
                list.add(p); // Adding object to the collection
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return list;
    }

    public ArrayList<Product> getProductsByCategory(String category) {
        ArrayList<Product> list = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE category = ?";
        
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, category);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Product p = new Product(
                    rs.getString("productCode"), rs.getString("name"),
                    rs.getString("category"), rs.getDouble("price"), rs.getInt("quantity")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return list;
    }

    @Override
    public boolean updateProduct(String code, String name, String category, double price, int qty) {
        String sql = "UPDATE products SET name = ?, category = ?, price = ?, quantity = ? WHERE productCode = ?";
        try (Connection conn = DatabaseConnectionFactory.getConnection(); 
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, category);
            pstmt.setDouble(3, price);
            pstmt.setInt(4, qty);
            pstmt.setString(5, code);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    @Override
    public boolean deleteProduct(String code) {
        String sql = "DELETE FROM products WHERE productCode = ?";
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, code);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}