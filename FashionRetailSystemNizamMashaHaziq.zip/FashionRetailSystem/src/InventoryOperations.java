import java.util.ArrayList;

// This interface acts as a strict blueprint for your Data classes
public interface InventoryOperations {
    boolean saveProduct(String code, String name, String category, double price, int qty);
    boolean updateProduct(String code, String name, String category, double price, int qty);
    boolean deleteProduct(String code);
    
    // Notice how this returns an ArrayList instead of a raw ResultSet!
    ArrayList<Product> getAllProducts(); 
}