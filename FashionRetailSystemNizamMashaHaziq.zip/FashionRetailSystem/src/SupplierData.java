import java.sql.*;
import java.util.ArrayList;

public class SupplierData {
    // Constraint: Semak sama ada SSM sudah wujud
    public boolean isSSMExists(String ssm) {
        String sql = "SELECT * FROM suppliers WHERE ssm = ?";
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ssm);
            return pstmt.executeQuery().next();
        } catch (SQLException e) {
            return false;
        }
    }

    // Basic Flow: Simpan Supplier baru
    public boolean saveSupplier(String name, String ssm, String phone, String address) {
        String sql = "INSERT INTO suppliers(name, ssm, phone, address) VALUES(?,?,?,?)";
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, ssm);
            pstmt.setString(3, phone);
            pstmt.setString(4, address);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
    // Ambil semua data supplier untuk dipaparkan di JTable
    public ArrayList<Supplier> getAllSuppliers() {
        ArrayList<Supplier> list = new ArrayList<>();
        String sql = "SELECT * FROM suppliers";
        
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Supplier s = new Supplier(
                    rs.getString("name"),
                    rs.getString("ssm"),
                    rs.getString("phone"),
                    rs.getString("address")
                );
                list.add(s);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching suppliers: " + e.getMessage());
        }
        return list;
    }
    // BASIC FLOW UC2: Update Supplier Details
    public boolean updateSupplier(String ssm, String phone, String address) {
        // Hanya update phone dan address berdasarkan SSM yang dikunci (locked)
        String sql = "UPDATE suppliers SET phone = ?, address = ? WHERE ssm = ?";
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, phone);
            pstmt.setString(2, address);
            pstmt.setString(3, ssm);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    // ALTERNATE FLOW UC2: Deactivate Supplier (Bukan Delete)
    public boolean deactivateSupplier(String ssm) {
        // Menukar status kepada Inactive mengikut spesifikasi PDF
        String sql = "UPDATE suppliers SET status = 'Inactive' WHERE ssm = ?";
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ssm);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }// Method untuk menarik senarai nama supplier dari pangkalan data
    public java.util.ArrayList<String> getSupplierNames() {
        java.util.ArrayList<String> suppliers = new java.util.ArrayList<>();
        // Hanya tarik supplier yang masih aktif
        String sql = "SELECT name FROM suppliers WHERE status = 'Active'";
        
        try (Connection conn = DatabaseConnectionFactory.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
             
            while (rs.next()) {
                suppliers.add(rs.getString("name"));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching suppliers: " + e.getMessage());
        }
        return suppliers;
    }
}