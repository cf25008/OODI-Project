import java.sql.*;

public class CategoryData {
    private Connection connect() {
        String url = "jdbc:mysql://localhost:3306/inventory_db";
        String user = "root";
        String password = ""; 
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            System.out.println("DB Error: " + e.getMessage());
        }
        return conn;
    }

    // CONSTRAINT 1: Check if category already exists (Must be unique)
    public boolean checkExists(String name) {
        String sql = "SELECT * FROM categories WHERE categoryName = ?";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            return pstmt.executeQuery().next(); // Returns true if it finds a match
        } catch (SQLException e) {
            return false;
        }
    }

    // EXCEPTION E1: Check if active products are using this category
    public boolean checkInUse(String categoryName) {
        String sql = "SELECT * FROM products WHERE category = ?";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, categoryName);
            return pstmt.executeQuery().next(); // Returns true if products are using it
        } catch (SQLException e) {
            return false;
        }
    }

    // BASIC FLOW: Add Category
    public boolean addCategory(String name) {
        String sql = "INSERT INTO categories (categoryName) VALUES (?)";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    // BASIC & EXCEPTION FLOW: Update Category
    public boolean updateCategory(String oldName, String newName) {
        String sqlCategory = "UPDATE categories SET categoryName = ? WHERE categoryName = ?";
        String sqlProducts = "UPDATE products SET category = ? WHERE category = ?"; // Reassigns products automatically!
        
        try (Connection conn = this.connect()) {
            // 1. Update the main category table
            try (PreparedStatement pstmt1 = conn.prepareStatement(sqlCategory)) {
                pstmt1.setString(1, newName);
                pstmt1.setString(2, oldName);
                pstmt1.executeUpdate();
            }
            // 2. Cascade the update to the products table to keep DB safe
            try (PreparedStatement pstmt2 = conn.prepareStatement(sqlProducts)) {
                pstmt2.setString(1, newName);
                pstmt2.setString(2, oldName);
                pstmt2.executeUpdate();
            }
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
    
    // Get all for the table
    public ResultSet getAllCategories() {
        try {
            Connection conn = this.connect();
            return conn.createStatement().executeQuery("SELECT * FROM categories");
        } catch (SQLException e) {
            return null;
        }
    }
        // DELETE: Remove Category
    public boolean deleteCategory(String categoryName) {
        String sql = "DELETE FROM categories WHERE categoryName = ?";
        try (Connection conn = this.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, categoryName);
            pstmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}